import React, { useEffect, useRef, useState, useCallback } from 'react';
import { FaceMesh, Results } from '@mediapipe/face_mesh';
import { Camera, AlertTriangle, CheckCircle2, Volume2, VolumeX, Settings, RefreshCcw, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Eye Aspect Ratio (EAR) Landmarks
const LEFT_EYE = [362, 385, 387, 263, 373, 380];
const RIGHT_EYE = [33, 160, 158, 133, 153, 144];

// EAR Calculation
const calculateEAR = (landmarks: any, eyeIndices: number[]) => {
  const p1 = landmarks[eyeIndices[0]];
  const p2 = landmarks[eyeIndices[1]];
  const p3 = landmarks[eyeIndices[2]];
  const p4 = landmarks[eyeIndices[3]];
  const p5 = landmarks[eyeIndices[4]];
  const p6 = landmarks[eyeIndices[5]];

  const dist = (a: any, b: any) => Math.sqrt(Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2));

  const vertical1 = dist(p2, p6);
  const vertical2 = dist(p3, p5);
  const horizontal = dist(p1, p4);

  return (vertical1 + vertical2) / (2.0 * horizontal);
};

export default function App() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrowsy, setIsDrowsy] = useState(false);
  const [ear, setEar] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [threshold, setThreshold] = useState(0.25);
  const [consecutiveFrames, setConsecutiveFrames] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const oscillatorRef = useRef<OscillatorNode | null>(null);

  // Sound Alert
  const playAlert = useCallback(() => {
    if (isMuted) return;
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume();
    }
    if (!oscillatorRef.current) {
      const osc = audioContextRef.current.createOscillator();
      const gain = audioContextRef.current.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(440, audioContextRef.current.currentTime);
      gain.gain.setValueAtTime(0.1, audioContextRef.current.currentTime);
      osc.connect(gain);
      gain.connect(audioContextRef.current.destination);
      osc.start();
      oscillatorRef.current = osc;
    }
  }, [isMuted]);

  const stopAlert = useCallback(() => {
    if (oscillatorRef.current) {
      oscillatorRef.current.stop();
      oscillatorRef.current.disconnect();
      oscillatorRef.current = null;
    }
  }, []);

  useEffect(() => {
    if (isDrowsy) {
      playAlert();
    } else {
      stopAlert();
    }
  }, [isDrowsy, playAlert, stopAlert]);

  useEffect(() => {
    const faceMesh = new FaceMesh({
      locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`,
    });

    faceMesh.setOptions({
      maxNumFaces: 1,
      refineLandmarks: true,
      minDetectionConfidence: 0.5,
      minTrackingConfidence: 0.5,
    });

    faceMesh.onResults((results: Results) => {
      if (!canvasRef.current || !videoRef.current) return;
      const canvasCtx = canvasRef.current.getContext('2d');
      if (!canvasCtx) return;

      canvasCtx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      
      if (results.multiFaceLandmarks && results.multiFaceLandmarks.length > 0) {
        const landmarks = results.multiFaceLandmarks[0];
        
        const leftEAR = calculateEAR(landmarks, LEFT_EYE);
        const rightEAR = calculateEAR(landmarks, RIGHT_EYE);
        const avgEAR = (leftEAR + rightEAR) / 2;
        setEar(avgEAR);

        if (avgEAR < threshold) {
          setConsecutiveFrames(prev => prev + 1);
        } else {
          setConsecutiveFrames(0);
          setIsDrowsy(false);
        }

        // Trigger drowsiness if eyes closed for ~1.5 seconds (assuming 30fps, 45 frames)
        if (consecutiveFrames > 30) {
          setIsDrowsy(true);
        }

        // Draw landmarks
        canvasCtx.fillStyle = isDrowsy ? '#ef4444' : '#22c55e';
        [...LEFT_EYE, ...RIGHT_EYE].forEach(index => {
          const point = landmarks[index];
          canvasCtx.beginPath();
          canvasCtx.arc(point.x * canvasRef.current!.width, point.y * canvasRef.current!.height, 2, 0, 2 * Math.PI);
          canvasCtx.fill();
        });
      }
    });

    let camera: any = null;
    const startCamera = async () => {
      if (!videoRef.current) return;
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          setIsCameraReady(true);
          const process = async () => {
            if (videoRef.current) {
              await faceMesh.send({ image: videoRef.current });
              requestAnimationFrame(process);
            }
          };
          process();
        };
      } catch (err) {
        console.error("Error accessing webcam:", err);
      }
    };

    startCamera();

    return () => {
      stopAlert();
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach(track => track.stop());
      }
    };
  }, [threshold, consecutiveFrames, stopAlert]);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-emerald-500/30">
      {/* Background Atmosphere */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500/10 blur-[120px] rounded-full" />
      </div>

      <main className="relative z-10 max-w-6xl mx-auto px-6 py-12">
        {/* Header */}
        <header className="flex items-center justify-between mb-12">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Camera className="w-6 h-6 text-black" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">DrowsyGuard AI</h1>
              <p className="text-zinc-500 text-sm">Real-time fatigue monitoring</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl hover:bg-zinc-800 transition-colors"
            >
              {isMuted ? <VolumeX className="w-5 h-5 text-zinc-400" /> : <Volume2 className="w-5 h-5 text-emerald-400" />}
            </button>
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl hover:bg-zinc-800 transition-colors"
            >
              <Settings className="w-5 h-5 text-zinc-400" />
            </button>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Monitor */}
          <div className="lg:col-span-2 space-y-6">
            <div className="relative aspect-video bg-zinc-900 rounded-3xl overflow-hidden border border-zinc-800 shadow-2xl">
              {!isCameraReady && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-900 z-20">
                  <RefreshCcw className="w-8 h-8 text-emerald-500 animate-spin mb-4" />
                  <p className="text-zinc-400">Initializing vision system...</p>
                </div>
              )}
              
              <video
                ref={videoRef}
                className="absolute inset-0 w-full h-full object-cover scale-x-[-1]"
                autoPlay
                playsInline
                muted
              />
              <canvas
                ref={canvasRef}
                className="absolute inset-0 w-full h-full object-cover scale-x-[-1] z-10"
                width={640}
                height={480}
              />

              {/* Status Overlay */}
              <div className="absolute top-6 left-6 z-20">
                <AnimatePresence mode="wait">
                  {isDrowsy ? (
                    <motion.div
                      initial={{ opacity: 0, y: -20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-full font-bold shadow-lg shadow-red-500/40"
                    >
                      <AlertTriangle className="w-5 h-5" />
                      DROWSINESS DETECTED
                    </motion.div>
                  ) : (
                    <motion.div
                      initial={{ opacity: 0, y: -20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="flex items-center gap-2 px-4 py-2 bg-emerald-500 text-black rounded-full font-bold shadow-lg shadow-emerald-500/40"
                    >
                      <CheckCircle2 className="w-5 h-5" />
                      SYSTEM ALERT
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* EAR Meter Overlay */}
              <div className="absolute bottom-6 left-6 right-6 z-20 flex items-center gap-4 bg-black/40 backdrop-blur-md p-4 rounded-2xl border border-white/10">
                <div className="flex-1">
                  <div className="flex justify-between text-xs font-mono text-zinc-400 mb-2">
                    <span>EYE ASPECT RATIO (EAR)</span>
                    <span>{ear.toFixed(3)}</span>
                  </div>
                  <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                    <motion.div
                      className={cn(
                        "h-full transition-colors duration-300",
                        ear < threshold ? "bg-red-500" : "bg-emerald-500"
                      )}
                      animate={{ width: `${Math.min(ear * 200, 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Info Cards */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl">
                <p className="text-zinc-500 text-sm mb-1">Current EAR</p>
                <p className="text-3xl font-mono font-bold text-emerald-400">{ear.toFixed(3)}</p>
              </div>
              <div className="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl">
                <p className="text-zinc-500 text-sm mb-1">Status</p>
                <p className={cn(
                  "text-3xl font-bold",
                  isDrowsy ? "text-red-500" : "text-emerald-500"
                )}>
                  {isDrowsy ? "DROWSY" : "ALERT"}
                </p>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="p-6 bg-zinc-900 border border-zinc-800 rounded-3xl">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <Info className="w-5 h-5 text-emerald-500" />
                How it works
              </h3>
              <div className="space-y-4 text-sm text-zinc-400 leading-relaxed">
                <p>
                  The system uses <span className="text-white">MediaPipe Face Mesh</span> to track 468 facial landmarks in real-time.
                </p>
                <p>
                  It calculates the <span className="text-white">Eye Aspect Ratio (EAR)</span>, which is the ratio of eye height to eye width.
                </p>
                <p>
                  If the EAR drops below <span className="text-white">{threshold}</span> for more than 1 second, an alert is triggered.
                </p>
              </div>
            </div>

            {showSettings && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="p-6 bg-zinc-900 border border-zinc-800 rounded-3xl"
              >
                <h3 className="text-lg font-bold mb-6">Sensitivity Settings</h3>
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-zinc-400">EAR Threshold</span>
                      <span className="text-emerald-500 font-mono">{threshold}</span>
                    </div>
                    <input
                      type="range"
                      min="0.15"
                      max="0.35"
                      step="0.01"
                      value={threshold}
                      onChange={(e) => setThreshold(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                    />
                    <p className="text-[10px] text-zinc-500 mt-2">
                      Lower values are less sensitive (require more eye closure).
                    </p>
                  </div>
                </div>
              </motion.div>
            )}

            <div className="p-6 bg-emerald-500/5 border border-emerald-500/10 rounded-3xl">
              <p className="text-xs text-emerald-500/60 uppercase tracking-widest font-bold mb-2">Safety Note</p>
              <p className="text-sm text-zinc-400">
                This tool is for demonstration. Never drive or operate heavy machinery if you feel fatigued.
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-6xl mx-auto px-6 py-8 border-t border-zinc-900 flex justify-between items-center text-zinc-600 text-xs">
        <p>© 2026 DrowsyGuard AI Vision Systems</p>
        <div className="flex gap-4">
          <span>TensorFlow.js</span>
          <span>MediaPipe</span>
          <span>OpenCV Logic</span>
        </div>
      </footer>
    </div>
  );
}
